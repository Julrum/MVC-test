import Observable from "../common/Observable";

class Model extends Observable {}

export default Model;
